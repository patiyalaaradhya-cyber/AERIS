# Tests package initializer
